webpackJsonp([141],{

/***/ 245:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("Object.defineProperty(__webpack_exports__, \"__esModule\", { value: true });\n/* harmony export (immutable) */ __webpack_exports__[\"getList\"] = getList;\n/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_request__ = __webpack_require__(8);\n\n\nfunction getList(params) {\n  return Object(__WEBPACK_IMPORTED_MODULE_0__utils_request__[\"default\"])({\n    url: '/table/list',\n    method: 'get',\n    params: params\n  });\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL2pzL2FwaS90YWJsZS5qcz8yMTM2Il0sIm5hbWVzIjpbImdldExpc3QiLCJwYXJhbXMiLCJyZXF1ZXN0IiwidXJsIiwibWV0aG9kIl0sIm1hcHBpbmdzIjoiOzs7QUFBQTs7QUFFTyxTQUFTQSxPQUFULENBQWlCQyxNQUFqQixFQUF5QjtBQUM5QixTQUFPLCtEQUFBQyxDQUFRO0FBQ2JDLFNBQUssYUFEUTtBQUViQyxZQUFRLEtBRks7QUFHYkg7QUFIYSxHQUFSLENBQVA7QUFLRCIsImZpbGUiOiIyNDUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgcmVxdWVzdCBmcm9tICd+L3V0aWxzL3JlcXVlc3QnXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0TGlzdChwYXJhbXMpIHtcclxuICByZXR1cm4gcmVxdWVzdCh7XHJcbiAgICB1cmw6ICcvdGFibGUvbGlzdCcsXHJcbiAgICBtZXRob2Q6ICdnZXQnLFxyXG4gICAgcGFyYW1zXHJcbiAgfSlcclxufVxyXG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9yZXNvdXJjZXMvYXNzZXRzL2pzL2FwaS90YWJsZS5qcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///245\n");

/***/ })

});